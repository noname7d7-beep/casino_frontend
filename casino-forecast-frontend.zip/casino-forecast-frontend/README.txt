Casino Forecast — Static frontend demo.
Open index.html in a browser. Click a slot to open Analysis, press Calculate, wait 7-10s for animated loading, see report.
